import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import emailjs from "@emailjs/browser";
import { Brain, Code2, Database, FileCode, Github, Linkedin, Mail, Phone, Download, ExternalLink, TrendingUp, Users, Zap } from "lucide-react";
import heroBackground from "@/assets/hero-bg.jpg";
const Index = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize EmailJS with your public key
  useEffect(() => {
    emailjs.init("x-n_YrWm4CxPsOkWn");
  }, []);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate input lengths
    const name = formData.name.trim();
    const email = formData.email.trim();
    const message = formData.message.trim();
    if (!name || name.length > 100) {
      toast.error("Name must be between 1 and 100 characters");
      return;
    }
    if (!email || email.length > 255 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Please enter a valid email address");
      return;
    }
    if (!message || message.length > 1000) {
      toast.error("Message must be between 1 and 1000 characters");
      return;
    }
    setIsSubmitting(true);
    try {
      // Send email using EmailJS
      await emailjs.send("service_ltfkgiq",
      // Your Service ID
      "template_hneve6f",
      // Your Template ID
      {
        from_name: name,
        from_email: email,
        message: message,
        to_name: "Shaziya Kauser M"
      });
      toast.success("Message sent successfully! I'll get back to you soon.");
      setFormData({
        name: "",
        email: "",
        message: ""
      });
    } catch (error) {
      console.error("EmailJS Error:", error);
      toast.error("Failed to send message. Please try again or contact me directly.");
    } finally {
      setIsSubmitting(false);
    }
  };
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: "smooth"
    });
  };
  return <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gradient-primary">SKM</h2>
            <div className="hidden md:flex items-center gap-8">
              {["Home", "About", "Experience", "Skills", "Services", "Projects", "Contact"].map(item => <button key={item} onClick={() => scrollToSection(item.toLowerCase())} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                    {item}
                  </button>)}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden" style={{
      backgroundImage: `url(${heroBackground})`,
      backgroundSize: "cover",
      backgroundPosition: "center"
    }}>
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background/95 to-primary/20" />
        
        {/* Animated Grid Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(hsl(263 70% 50% / 0.1) 1px, transparent 1px), linear-gradient(90deg, hsl(263 70% 50% / 0.1) 1px, transparent 1px)`,
          backgroundSize: '50px 50px'
        }} />
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{
        animationDelay: '1s'
      }} />

        <div className="container mx-auto px-6 py-32 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 animate-fade-in-left">
              {/* Status Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 backdrop-blur-sm border border-primary/20">
                <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
                <span className="text-sm font-medium text-foreground">Available for opportunities</span>
              </div>

              {/* Main Heading */}
              <div className="space-y-4">
                <h1 className="text-7xl lg:text-9xl font-bold leading-none tracking-tight">
                  Shaziya
                  <br />
                  <span className="text-gradient-primary inline-block animate-fade-in" style={{
                  animationDelay: '0.2s'
                }}>
                    Kauser M
                  </span>
                </h1>
                <div className="flex flex-wrap items-center gap-3 text-lg text-muted-foreground">
                  <span className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-primary" />
                    AI-ML Developer
                  </span>
                  <span className="text-primary">•</span>
                  <span className="flex items-center gap-2">
                    <Code2 className="w-5 h-5 text-accent" />
                    Web Enthusiast
                  </span>
                  <span className="text-primary">•</span>
                  <span className="flex items-center gap-2">
                    <Database className="w-5 h-5 text-primary" />
                    Data Explorer
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
                Crafting intelligent solutions through AI and machine learning, with a passion for
                transforming data into actionable insights.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-wrap gap-4 pt-4">
                <Button size="lg" onClick={() => scrollToSection("projects")} className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground glow-primary group relative overflow-hidden">
                  <span className="relative z-10 flex items-center gap-2">
                    View My Work
                    <ExternalLink className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </Button>
                <Button size="lg" variant="outline" onClick={() => scrollToSection("contact")} className="border-2 border-primary/30 bg-background/50 backdrop-blur-sm text-foreground hover:bg-primary/10 hover:border-primary group">
                  <span className="flex items-center gap-2">
                    Get in Touch
                    <Mail className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </span>
                </Button>
              </div>

              {/* Stats */}
              <div className="flex flex-wrap gap-8 pt-8">
                <div className="space-y-1">
                  <div className="text-3xl font-bold text-gradient-primary">3+</div>
                  <div className="text-sm text-muted-foreground">Months Experience</div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl font-bold text-gradient-accent">10+</div>
                  <div className="text-sm text-muted-foreground">Skills Mastered</div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl font-bold text-gradient-primary">1</div>
                  <div className="text-sm text-muted-foreground">Published Research</div>
                </div>
              </div>
            </div>

            {/* Profile Image Section */}
            <div className="flex justify-center lg:justify-end animate-fade-in-right">
              <div className="relative">
                {/* Glow Effects */}
                <div className="absolute -inset-4 bg-gradient-to-r from-primary/30 to-accent/30 rounded-3xl blur-2xl animate-glow-pulse" />
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-3xl blur-xl" />
                
                {/* Decorative Elements */}
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-primary/20 rounded-2xl rotate-12 backdrop-blur-sm border border-primary/30" />
                <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-accent/20 rounded-2xl -rotate-12 backdrop-blur-sm border border-accent/30" />
                
                {/* Main Image Container */}
                <div className="relative bg-card/30 backdrop-blur-sm rounded-3xl p-2 border border-border/50">
                  <img src="https://i.postimg.cc/qMBwM9Dz/Whats-App-Image-2025-09-30-at-3-46-41-PM.jpg" alt="Shaziya Kauser M" className="relative rounded-2xl w-full max-w-md shadow-2xl card-shadow" />
                  
                  {/* Floating Badge */}
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-card/80 backdrop-blur-md rounded-2xl px-6 py-3 border border-border/50 shadow-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                        <Zap className="w-5 h-5 text-background" />
                      </div>
                      <div>
                        <div className="text-sm font-bold">Data Science Intern</div>
                        <div className="text-xs text-muted-foreground">Redington Gulf, Dubai</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-primary/50 flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-primary rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-20 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-5xl mx-auto">
            {/* Section Header */}
            <div className="text-center mb-16 space-y-4 animate-fade-in">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 backdrop-blur-sm border border-primary/20 mb-4">
                <span className="text-sm font-medium text-primary">Who I Am</span>
              </div>
              <h2 className="text-5xl font-bold">
                About <span className="text-gradient-accent">Me</span>
              </h2>
            </div>

            <div className="grid lg:grid-cols-2 gap-8 animate-fade-in">
              {/* Bio Card */}
              <Card className="p-8 bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm border-border/50 card-shadow hover:glow-primary transition-all duration-300 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-2xl group-hover:bg-primary/20 transition-all duration-300" />
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                      <Brain className="w-6 h-6 text-background" />
                    </div>
                    <h3 className="text-2xl font-bold">My Journey</h3>
                  </div>
                  <p className="text-base text-muted-foreground leading-relaxed">
                    Aspiring AI-ML developer with a good foundation in Python, HTML, CSS, JavaScript, C,
                    SQL, C++, Git, and GitHub. Passionate about crafting web applications and solving
                    problems using AI. Eager to gain hands-on experience in building models and working
                    with data to create innovative solutions.
                  </p>
                </div>
              </Card>

              {/* Education Card */}
              <Card className="p-8 bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm border-border/50 card-shadow hover:glow-primary transition-all duration-300 relative overflow-hidden group">
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-accent/10 rounded-full blur-2xl group-hover:bg-accent/20 transition-all duration-300" />
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-primary flex items-center justify-center">
                      <FileCode className="w-6 h-6 text-background" />
                    </div>
                    <h3 className="text-2xl font-bold text-gradient-primary">Education</h3>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4 p-4 rounded-xl bg-muted/30 border border-border/30">
                      <div className="w-3 h-3 bg-gradient-to-br from-primary to-accent rounded-full mt-1 flex-shrink-0 animate-pulse" />
                      <div className="space-y-1">
                        <h4 className="font-bold text-lg">Bachelor of Technology</h4>
                        <p className="text-foreground font-medium">SIMATS</p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>2023 - 2027</span>
                          <span className="text-accent">•</span>
                          <span className="text-accent font-medium">In Progress</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-24 bg-card/30 relative overflow-hidden">
        {/* Decorative Elements */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 left-1/4 w-px h-full bg-gradient-to-b from-transparent via-primary/20 to-transparent" />
          <div className="absolute top-0 right-1/4 w-px h-full bg-gradient-to-b from-transparent via-accent/20 to-transparent" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16 space-y-4 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 backdrop-blur-sm border border-accent/20 mb-4">
              <span className="text-sm font-medium text-accent">Professional Journey</span>
            </div>
            <h2 className="text-5xl font-bold">
              Work <span className="text-gradient-accent">Experience</span>
            </h2>
          </div>

          <div className="max-w-5xl mx-auto animate-fade-in">
            <Card className="p-10 bg-gradient-to-br from-card/90 to-card/50 backdrop-blur-sm border-border/50 card-shadow hover:glow-primary transition-all duration-300 relative overflow-hidden group">
              {/* Background Gradient */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-primary/10 to-accent/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700" />
              
              <div className="relative z-10">
                {/* Header Section */}
                <div className="flex flex-col md:flex-row md:items-start gap-6 mb-8 pb-6 border-b border-border/50">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0 shadow-lg">
                    <TrendingUp className="w-8 h-8 text-background" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-3xl font-bold mb-3">Data Science Intern</h3>
                    <div className="flex flex-wrap items-center gap-3 mb-2">
                      <p className="text-primary font-bold text-lg">Redington Gulf</p>
                      <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                      <p className="text-muted-foreground font-medium">Dubai, UAE</p>
                    </div>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 border border-accent/20">
                      <span className="text-sm font-medium text-accent">August 2025 - October 2025</span>
                    </div>
                  </div>
                </div>

                {/* Achievements Grid */}
                <div className="grid md:grid-cols-2 gap-4">
                  {[{
                  icon: Database,
                  title: "Data Analysis",
                  desc: "Performed exploratory data analysis (EDA) on company sales datasets"
                }, {
                  icon: Brain,
                  title: "Model Building",
                  desc: "Built a linear regression model to forecast sales with high accuracy"
                }, {
                  icon: Users,
                  title: "Team Collaboration",
                  desc: "Collaborated with a team of three professionals on technical solutions"
                }, {
                  icon: FileCode,
                  title: "Documentation",
                  desc: "Created comprehensive reports, summaries, and flowcharts for presentations"
                }].map((item, index) => <div key={index} className="flex gap-4 p-4 rounded-xl bg-muted/20 border border-border/30 hover:bg-muted/30 hover:border-primary/30 transition-all duration-300 group/item">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover/item:bg-primary/20 transition-colors">
                        <item.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-bold text-sm">{item.title}</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                      </div>
                    </div>)}
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-24 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute top-40 left-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-40 right-10 w-72 h-72 bg-accent/5 rounded-full blur-3xl animate-pulse" style={{
        animationDelay: '1s'
      }} />
        
        <div className="container mx-auto px-6 relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16 space-y-4 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 backdrop-blur-sm border border-primary/20 mb-4">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Tech Stack</span>
            </div>
            <h2 className="text-5xl font-bold">
              Technical <span className="text-gradient-accent">Skills</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              A diverse toolkit spanning programming, data science, and modern development practices
            </p>
          </div>

          <div className="max-w-6xl mx-auto grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[{
            title: "Programming Languages",
            icon: Code2,
            skills: ["Python", "SQL", "JavaScript", "C", "C++"],
            color: "from-primary to-primary/60"
          }, {
            title: "Web Development",
            icon: FileCode,
            skills: ["HTML", "CSS", "Django"],
            color: "from-accent to-accent/60"
          }, {
            title: "Tools & Platforms",
            icon: Github,
            skills: ["Git", "GitHub"],
            color: "from-primary to-accent"
          }, {
            title: "Data Analysis",
            icon: Database,
            skills: ["Excel", "Power BI", "ANOVA", "Chi-Square"],
            color: "from-accent to-primary"
          }, {
            title: "Machine Learning",
            icon: Brain,
            skills: ["Linear Regression", "Logistic Regression", "Predictive Analytics"],
            color: "from-primary/80 to-accent/80"
          }, {
            title: "Soft Skills",
            icon: Users,
            skills: ["Organization", "Time Management", "Communication", "Interpersonal"],
            color: "from-accent/80 to-primary/80"
          }].map((category, index) => <Card key={index} className="p-6 bg-gradient-to-br from-card/90 to-card/40 backdrop-blur-sm border-border/50 card-shadow hover:glow-primary transition-all duration-300 group relative overflow-hidden animate-scale-in" style={{
            animationDelay: `${index * 0.1}s`
          }}>
                {/* Hover Gradient Effect */}
                <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
                
                <div className="relative z-10">
                  {/* Icon Header */}
                  <div className="flex items-center gap-3 mb-5">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center shadow-lg`}>
                      <category.icon className="w-6 h-6 text-background" />
                    </div>
                    <h3 className="font-bold text-lg leading-tight">{category.title}</h3>
                  </div>
                  
                  {/* Skills Tags */}
                  <div className="flex flex-wrap gap-2">
                    {category.skills.map((skill, i) => <span key={i} className="px-3 py-1.5 text-sm bg-muted/50 backdrop-blur-sm rounded-lg text-foreground border border-border/30 hover:border-primary/30 hover:bg-muted/70 transition-all duration-200 font-medium">
                        {skill}
                      </span>)}
                  </div>
                </div>
              </Card>)}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-card/30 relative overflow-hidden">
        {/* Grid Pattern Background */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at center, hsl(263 70% 50% / 0.15) 1px, transparent 1px)`,
          backgroundSize: '30px 30px'
        }} />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16 space-y-4 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 backdrop-blur-sm border border-accent/20 mb-4">
              <Zap className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-accent">Services</span>
            </div>
            <h2 className="text-5xl font-bold">
              What I <span className="text-gradient-accent">Offer</span>
            </h2>
          </div>

          <div className="max-w-6xl mx-auto">
            <Card className="p-12 bg-gradient-to-br from-card/90 via-card/70 to-card/40 backdrop-blur-sm border-border/50 card-shadow hover:glow-primary transition-all duration-500 relative overflow-hidden group animate-fade-in">
              {/* Animated Background Elements */}
              <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-primary/10 to-accent/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000" />
              <div className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-accent/10 to-primary/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000" />
              
              <div className="relative z-10">
                <div className="flex flex-col lg:flex-row items-start gap-8">
                  {/* Icon Section */}
                  <div className="flex-shrink-0">
                    <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-primary via-accent to-primary flex items-center justify-center shadow-2xl relative group-hover:scale-110 transition-transform duration-300">
                      <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-primary to-accent opacity-0 group-hover:opacity-100 blur animate-glow-pulse" />
                      <Zap className="w-12 h-12 text-background relative z-10" />
                    </div>
                  </div>

                  {/* Content Section */}
                  <div className="flex-1 space-y-6">
                    <div>
                      <h3 className="text-4xl font-bold mb-4 text-gradient-primary">
                        AI-ML Engineering
                      </h3>
                      <p className="text-lg text-muted-foreground leading-relaxed">
                        Building intelligent models and data-driven solutions using cutting-edge machine
                        learning techniques. Specializing in predictive analytics, pattern recognition, and
                        problem-solving with AI to deliver actionable insights and automated solutions for
                        real-world challenges.
                      </p>
                    </div>

                    {/* Service Features Grid */}
                    <div className="grid md:grid-cols-2 gap-4 pt-4">
                      {[{
                      icon: Brain,
                      label: "Machine Learning Models"
                    }, {
                      icon: TrendingUp,
                      label: "Predictive Analytics"
                    }, {
                      icon: Database,
                      label: "Data Processing"
                    }, {
                      icon: Code2,
                      label: "Algorithm Development"
                    }].map((feature, idx) => <div key={idx} className="flex items-center gap-3 p-3 rounded-xl bg-muted/20 border border-border/30 hover:bg-muted/40 hover:border-primary/30 transition-all duration-300">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <feature.icon className="w-5 h-5 text-primary" />
                          </div>
                          <span className="font-medium">{feature.label}</span>
                        </div>)}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 relative overflow-hidden">
        {/* Background Decorations */}
        <div className="absolute top-20 right-20 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-64 h-64 bg-accent/5 rounded-full blur-3xl" />
        
        <div className="container mx-auto px-6 relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16 space-y-4 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 backdrop-blur-sm border border-primary/20 mb-4">
              <FileCode className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Portfolio</span>
            </div>
            <h2 className="text-5xl font-bold">
              Featured <span className="text-gradient-accent">Projects</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Research and development work in AI, machine learning, and cloud computing
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <Card className="overflow-hidden bg-gradient-to-br from-card/90 to-card/40 backdrop-blur-sm border-border/50 card-shadow hover:glow-primary transition-all duration-500 group relative animate-fade-in">
              {/* Gradient Background */}
              <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-primary/10 to-accent/5 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700" />
              
              <div className="relative z-10 p-10">
                {/* Project Header */}
                <div className="flex flex-col sm:flex-row items-start justify-between gap-4 mb-6 pb-6 border-b border-border/50">
                  <div className="flex-1">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-xs font-medium text-accent mb-3">
                      Published Research • 2024
                    </div>
                    <h3 className="text-3xl font-bold mb-2 group-hover:text-gradient-primary transition-all duration-300">
                      Node Failure Prediction in Cloud Environment
                    </h3>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors flex-shrink-0">
                    <ExternalLink className="w-6 h-6 text-primary" />
                  </div>
                </div>

                {/* Project Description */}
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Conducted comprehensive predictive analysis using advanced time series modeling
                  techniques to enhance cloud infrastructure reliability and prevent system failures.
                  This research contributes to improving operational efficiency in cloud computing environments.
                </p>

                {/* Achievements */}
                <div className="space-y-4 mb-8">
                  <h4 className="font-bold text-sm uppercase tracking-wider text-primary">Key Achievements</h4>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="flex gap-4 p-4 rounded-xl bg-muted/20 border border-border/30">
                      <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                        <Users className="w-5 h-5 text-accent" />
                      </div>
                      <div>
                        <p className="font-semibold text-sm mb-1">International Conference</p>
                        <p className="text-xs text-muted-foreground">
                          Presented at AI Conference, Malaysia
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-4 p-4 rounded-xl bg-muted/20 border border-border/30">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <FileCode className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold text-sm mb-1">Published Paper</p>
                        <p className="text-xs text-muted-foreground">
                          IRAJ Publications
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Tech Stack Tags */}
                <div>
                  <h4 className="font-bold text-sm uppercase tracking-wider text-primary mb-3">Technologies</h4>
                  <div className="flex flex-wrap gap-2">
                    {["Machine Learning", "Time Series Analysis", "Cloud Computing", "Predictive Analytics", "Python"].map(tag => <span key={tag} className="px-4 py-2 text-sm bg-primary/10 text-primary rounded-xl font-medium border border-primary/20 hover:bg-primary/20 hover:border-primary/30 transition-all duration-200">
                          {tag}
                        </span>)}
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-card/30 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, hsl(263 70% 50% / 0.1) 0%, transparent 50%), radial-gradient(circle at 80% 50%, hsl(177 70% 50% / 0.1) 0%, transparent 50%)`
        }} />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16 space-y-4 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 backdrop-blur-sm border border-accent/20 mb-4">
              <Mail className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-accent">Let's Connect</span>
            </div>
            <h2 className="text-5xl font-bold">
              Get In <span className="text-gradient-accent">Touch</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Have a project in mind or want to collaborate? I'd love to hear from you!
            </p>
          </div>

          <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-8">
            {/* Contact Info Card */}
            <div className="space-y-6 animate-fade-in-left">
              <Card className="p-8 bg-gradient-to-br from-card/90 to-card/40 backdrop-blur-sm border-border/50 card-shadow hover:glow-primary transition-all duration-300 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl group-hover:bg-primary/10 transition-all duration-500" />
                
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
                  <div className="space-y-4">
                    <a href="mailto:shaziya.kauser@example.com" className="flex items-center gap-4 p-4 rounded-xl text-muted-foreground hover:text-primary transition-all duration-300 bg-muted/20 hover:bg-muted/40 border border-border/30 hover:border-primary/30 group/item">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center group-hover/item:scale-110 transition-transform shadow-lg">
                        <Mail className="w-6 h-6 text-background" />
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Email</div>
                        <span className="font-medium"></span>
                      </div>
                    </a>
                    
                    <a href="tel:+971501234567" className="flex items-center gap-4 p-4 rounded-xl text-muted-foreground hover:text-primary transition-all duration-300 bg-muted/20 hover:bg-muted/40 border border-border/30 hover:border-primary/30 group/item">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-primary flex items-center justify-center group-hover/item:scale-110 transition-transform shadow-lg">
                        <Phone className="w-6 h-6 text-background" />
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Phone</div>
                        <span className="font-medium">+971 542133135</span>
                      </div>
                    </a>
                    
                    <a href="https://linkedin.com/in/shaziyakauser" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 rounded-xl text-muted-foreground hover:text-primary transition-all duration-300 bg-muted/20 hover:bg-muted/40 border border-border/30 hover:border-primary/30 group/item">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center group-hover/item:scale-110 transition-transform shadow-lg">
                        <Linkedin className="w-6 h-6 text-background" />
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">LinkedIn</div>
                        <span className="font-medium">linkedin.com/in/shaziyakauserm</span>
                      </div>
                    </a>
                    
                    <a href="https://github.com/shaziyakauser" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 rounded-xl text-muted-foreground hover:text-primary transition-all duration-300 bg-muted/20 hover:bg-muted/40 border border-border/30 hover:border-primary/30 group/item">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-primary flex items-center justify-center group-hover/item:scale-110 transition-transform shadow-lg">
                        <Github className="w-6 h-6 text-background" />
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">GitHub</div>
                        <span className="font-medium">github.com/shaziyakhann</span>
                      </div>
                    </a>
                  </div>

                  {/* Resume Download */}
                  <a href="/shaziyakauserm.pdf" download="Shaziya_Kauser_Resume.pdf" className="block w-full mt-6">
                    <Button className="w-full bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 text-accent-foreground shadow-lg hover:shadow-xl transition-all duration-300" size="lg">
                      <Download className="w-5 h-5 mr-2" />
                      Download Resume
                    </Button>
                  </a>
                </div>
              </Card>
            </div>

            {/* Contact Form Card */}
            <Card className="p-8 bg-gradient-to-br from-card/90 to-card/40 backdrop-blur-sm border-border/50 card-shadow hover:glow-primary transition-all duration-300 relative overflow-hidden group animate-fade-in-right">
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl group-hover:bg-accent/10 transition-all duration-500" />
              
              <div className="relative z-10">
                <h3 className="text-2xl font-bold mb-6">Send a Message</h3>
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Name</label>
                    <Input placeholder="Your Name" value={formData.name} onChange={e => setFormData({
                    ...formData,
                    name: e.target.value
                  })} required className="bg-muted/50 border-border/50 focus:border-primary/50 transition-colors h-12" />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Email</label>
                    <Input type="email" placeholder="your.email@example.com" value={formData.email} onChange={e => setFormData({
                    ...formData,
                    email: e.target.value
                  })} required className="bg-muted/50 border-border/50 focus:border-primary/50 transition-colors h-12" />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Message</label>
                    <Textarea placeholder="Tell me about your project or inquiry..." value={formData.message} onChange={e => setFormData({
                    ...formData,
                    message: e.target.value
                  })} required rows={6} className="bg-muted/50 border-border/50 focus:border-primary/50 transition-colors resize-none" />
                  </div>
                  <Button type="submit" disabled={isSubmitting} className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground shadow-lg hover:shadow-xl transition-all duration-300" size="lg">
                    {isSubmitting ? "Sending..." : "Send Message"}
                    <Mail className="w-4 h-4 ml-2" />
                  </Button>
                </form>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border/50 bg-card/20 backdrop-blur-sm relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(hsl(263 70% 50% / 0.1) 1px, transparent 1px), linear-gradient(90deg, hsl(263 70% 50% / 0.1) 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }} />
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <span className="text-background font-bold text-lg">SK</span>
              </div>
              <div>
                <p className="font-bold">Shaziya Kauser M</p>
                <p className="text-sm text-muted-foreground">AI-ML Developer</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <a href="https://linkedin.com/in/shaziyakauser" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-muted/30 hover:bg-primary/20 flex items-center justify-center transition-colors border border-border/30 hover:border-primary/30">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="https://github.com/shaziyakauser" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-muted/30 hover:bg-primary/20 flex items-center justify-center transition-colors border border-border/30 hover:border-primary/30">
                <Github className="w-5 h-5" />
              </a>
              <a href="mailto:shaziya.kauser@example.com" className="w-10 h-10 rounded-lg bg-muted/30 hover:bg-primary/20 flex items-center justify-center transition-colors border border-border/30 hover:border-primary/30">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-border/30 text-center">
            <p className="text-sm text-muted-foreground">
              © 2025 Shaziya Kauser M. All rights reserved. Built with passion and precision.
            </p>
          </div>
        </div>
      </footer>
    </div>;
};
export default Index;